import sys

from boss import __version__
from boss.bo.bo_main import BOMain
from boss.settings import Settings
from boss.io.main_output import MainOutput
from boss.mep.mepmain import MEPMain
from boss.pp.pp_main import PPMain
from boss.bo.rstmanager import RstManager
from boss.utils.timer import Timer
from boss.io.parse import parse_input_file


def main(args=None):
    """The main routine."""
    # start timers
    local_timer = Timer()

    if args is None:
        args = sys.argv[1:]

    if not args_ok(args):  # Exit immediately if one or more args are invalid.
        print(
            "BOSS version "
            + str(__version__)
            + "\n"
            + "Usage:\n"
            + "   boss op <inputfile or rst-file>\n"
            + "   boss o <inputfile or rst-file>\n"
            + "   boss p <rst-file> <out-file>\n"
            + "   boss m <rst-file> <minima-file>\n"
            + "   boss v <rst-file> <out-file> <x_csv>\n"
            + "   boss v <rst-file> <out-file> points <x1> <x2> ... <xD>\n"
            + "   boss v <rst-file> <out-file> file <points_file>\n"
            + "   boss c <rst-file> <out-file> <idx_csv> <val_csv> [all]\n"
            + "   boss c <rst-file> <out-file> fix <idx> <val> [fix <idx> <val> ...] [all]\n"
            + "   boss c <rst-file> <out-file> fixfile <pairs_file> [all]\n"
            + "   boss c <rst-file> <out-file> idxfile <idx_file> valfile <val_file> [all]\n"
            + "See the documentation for further instructions."
        )
        return

    if not files_ok(args[1:]):  # Exit immediately if input file doesn't open.
        return

    input_data = parse_input_file(args[1])
    settings = Settings(input_data["keywords"])

    # Don't overwrite an optimization run's outfile.
    if len(args) == 3:
        ipt_outfile = args[2]
        if "m" in args[0]:
            settings["outfile"] = settings["outfile"][:-4] + "_mep.out"
        else:
            settings["outfile"] = settings["outfile"][:-4] + "_pp.out"

    main_output = None

    # 1. Run bayesian optimization. Note: if we run an optimization we let BOMain
    # handle the MainOutput
    if "o" in args[0] and (settings["initpts"] + settings["iterpts"]) > 0:
        local_timer.startLap()

        rst_data = input_data.get("rst_data", None)
        bo = BOMain.from_settings(settings, rst_data)
        main_output = bo.main_output
        bo.run()

        main_output.progress_msg(
            "| Bayesian optimization completed, "
            + "time [s] %s" % (local_timer.str_lapTime()),
            1,
            True,
            True,
        )

    # If no optmization was run, we need to initialize the MainOutput.
    # For v/c we should not overwrite the existing out-file.
    if not main_output:
        main_output = MainOutput(settings)
        if ("p" in args[0]) or ("m" == args[0]):
            main_output.new_file()

    # 2. Run post-processing.
    if "p" in args[0] and len(settings["pp_iters"]) > 0:
        local_timer.startLap()
        main_output.progress_msg("Starting post-processing...", 1, True)
        main_output.section_header("POST-PROCESSING")

        ipt_rstfile = settings["rstfile"] if "o" in args[0] else args[1]
        if len(args) != 3:
            ipt_outfile = settings["outfile"]

        settings["rstfile"] = ipt_rstfile
        settings["outfile"] = ipt_outfile

        pp_main = PPMain.from_settings(settings, main_output)
        pp_main.run()

        main_output.progress_msg(
            "Post-processing completed, " + "time [s] %s" % (local_timer.str_lapTime()),
            1,
        )

    # 3. Find minimum energy paths.
    if "m" == args[0]:
        local_timer.startLap()
        main_output.progress_msg("Finding minimum energy paths...", 1, True)
        main_output.section_header("MINIMUM ENERGY PATHS")

        MEPMain(settings, args[1], args[2], main_output)
        main_output.progress_msg(
            "Finding minimum energy paths completed, "
            + "time [s] %s" % (local_timer.str_lapTime()),
            1,
        )

    # 2b. Predict value at a given full x (CSV string or points list)
    if "v" == args[0]:
        local_timer.startLap()
        main_output.progress_msg("Predicting value at given x...", 1, True)
        main_output.section_header("PREDICT VALUE")

        ipt_rstfile = args[1]
        ipt_outfile = args[2]

        settings["rstfile"] = ipt_rstfile
        settings["outfile"] = ipt_outfile

        pp_main = PPMain.from_file(ipt_rstfile, ipt_outfile, main_output=main_output)

        def _read_points_file(path):
            pts = []
            with open(path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = [p for p in line.replace(",", " ").split() if p != ""]
                    pts.append([float(p) for p in parts])
            return pts

        if len(args) >= 5 and args[3].lower() == "points":
            x_vals = [float(tok) for tok in args[4:]]
            mu, var = pp_main.predict_at(x_vals)
            pp_main.write_prediction(x_vals, mu, var, label="cli_v")
            main_output.progress_msg(f"x={x_vals} -> mu={mu:.10g}, var={var:.10g}")
        elif len(args) >= 5 and args[3].lower() == "file":
            pts = _read_points_file(args[4])
            for row in pts:
                mu, var = pp_main.predict_at(row)
                pp_main.write_prediction(row, mu, var, label="cli_v")
                main_output.progress_msg(
                    f"x={row} -> mu={mu:.10g}, var={var:.10g}"
                )
        else:
            x_csv = args[3]
            x_vals = [float(tok) for tok in x_csv.split(",") if tok != ""]
            mu, var = pp_main.predict_at(x_vals)
            pp_main.write_prediction(x_vals, mu, var, label="cli_v")
            main_output.progress_msg(f"x={x_vals} -> mu={mu:.10g}, var={var:.10g}")
        main_output.footer(local_timer.str_totalTime())

    # 2c. Constrained minimize with fixed indices/values
    if "c" == args[0]:
        local_timer.startLap()
        main_output.progress_msg(
            "Constrained minimization with fixed variables...", 1, True
        )
        main_output.section_header("CONSTRAINED MINIMIZATION")

        ipt_rstfile = args[1]
        ipt_outfile = args[2]

        settings["rstfile"] = ipt_rstfile
        settings["outfile"] = ipt_outfile

        pp_main = PPMain.from_file(ipt_rstfile, ipt_outfile, main_output=main_output)
        fixed_indices = []
        fixed_values = []
        return_all = False
        if len(args) >= 5 and args[3].lower() == "fix":
            i = 3
            while i < len(args):
                token = args[i].lower()
                if token == "fix":
                    if i + 2 >= len(args):
                        raise ValueError("'fix' requires two arguments: <idx> <val>")
                    fixed_indices.append(int(args[i + 1]))
                    fixed_values.append(float(args[i + 2]))
                    i += 3
                elif token == "all":
                    return_all = True
                    i += 1
                else:
                    i += 1
        elif len(args) >= 5 and args[3].lower() == "fixfile":
            path = args[4]
            with open(path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith("#"):
                        continue
                    parts = [p for p in line.replace(",", " ").split() if p != ""]
                    if len(parts) < 2:
                        continue
                    fixed_indices.append(int(float(parts[0])))
                    fixed_values.append(float(parts[1]))
            if len(args) >= 6 and args[-1].lower() == "all":
                return_all = True
        elif (
            len(args) >= 7
            and args[3].lower() == "idxfile"
            and args[5].lower() == "valfile"
        ):
            idx_path = args[4]
            val_path = args[6]

            def _read_single_col(path):
                vals = []
                with open(path, "r") as f:
                    for line in f:
                        line = line.strip()
                        if not line or line.startswith("#"):
                            continue
                        parts = [p for p in line.replace(",", " ").split() if p != ""]
                        for p in parts:
                            vals.append(float(p))
                return vals

            idxs = _read_single_col(idx_path)
            vals = _read_single_col(val_path)
            if len(idxs) != len(vals):
                raise ValueError("idxfile 与 valfile 的长度不一致")
            fixed_indices = [int(i) for i in idxs]
            fixed_values = [float(v) for v in vals]
            if len(args) >= 8 and args[-1].lower() == "all":
                return_all = True
        else:
            idx_csv = args[3]
            val_csv = args[4]
            return_all = len(args) >= 6 and args[5].lower() == "all"
            fixed_indices = [int(tok) for tok in idx_csv.split(",") if tok != ""]
            fixed_values = [float(tok) for tok in val_csv.split(",") if tok != ""]

        result = pp_main.minimize_with_fixed(
            fixed_indices=fixed_indices,
            fixed_values=fixed_values,
            itr=None,
            accuracy=None,
            lowest_min_only=not return_all,
        )
        pp_main.write_constrained_minima(
            fixed_indices, fixed_values, result, label="cli_c"
        )
        if return_all:
            for i, (x_full, mu, var) in enumerate(result):
                main_output.progress_msg(
                    f"min[{i}]: x={x_full.tolist()} -> mu={mu:.10g}, var={var:.10g}"
                )
        else:
            x_full, mu, var = result
            main_output.progress_msg(
                f"x*={x_full.tolist()} -> mu={mu:.10g}, var={var:.10g}"
            )
        main_output.footer(local_timer.str_totalTime())

    main_output.footer(local_timer.str_totalTime())


def args_ok(args):
    """
    Checks that the user has called BOSS properly by examining the arguments
    given, number of files and filename extensions. BOSS should be called with
    one of the following:
        boss o options/.rst-file
        boss op options/.rst-file
        boss p .rst-file .out-file
        boss m .rst-file local_minima.dat
    """
    # TODO prevent calling boss pm
    some_args = len(args) > 0
    if some_args:
        optim_ok = "o" in args[0] and len(args) == 2
        justpp_arg_ok = "o" not in args[0] and "p" in args[0] and len(args) == 3
        mep_arg_ok = "o" not in args[0] and "m" in args[0] and len(args) == 3
        v_arg_ok = "v" == args[0] and len(args) >= 4
        c_arg_ok = "c" == args[0] and len(args) >= 5
        rst_incl = len(args) >= 2 and ".rst" in args[1]
        out_incl = len(args) >= 3 and ".out" in args[2]
        dat_incl = len(args) == 3 and ".dat" in args[2]
        justpp_ok = justpp_arg_ok and rst_incl and out_incl
        mep_ok = mep_arg_ok and rst_incl and dat_incl
        v_ok = v_arg_ok and rst_incl and out_incl
        c_ok = c_arg_ok and rst_incl and out_incl
    return some_args and (optim_ok or justpp_ok or mep_ok or v_ok or c_ok)


def files_ok(filenames):
    """
    Checks that the given files exist and can be opened.
    """
    for fname in filenames:
        # 只校验看起来像文件的参数，避免把子命令当成文件名
        if "." not in fname:
            continue
        # 数字参数（如 1.23）不应被当作文件名
        try:
            float(fname)
            continue
        except ValueError:
            pass
        try:
            f = open(fname, "r")
            f.close()
        except FileNotFoundError:
            print("Could not find file '" + fname + "'")
            return False
    return True


# Start BOSS
if __name__ == "__main__":
    main()
